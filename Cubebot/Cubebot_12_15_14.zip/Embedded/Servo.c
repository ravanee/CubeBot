#include "Timer.h"
#include "Types.h"
#include "Servo.h"

#define SERVO_LEFT_LIMIT      (800)
#define SERVO_RIGHT_LIMIT     (2200)
#define SERVO_STEPS_PER_45DEG (500)

static void ServoMoveTimeoutHandler(void * Servo);


BOOL SERVO_SetPosition(ServoCtrl * Servo, uint16 Position)
{
     if(Servo)
     {
          if((Position > SERVO_LEFT_LIMIT) && (Position < SERVO_RIGHT_LIMIT))
          {
               TIMER_SetCCR(Servo->Pwm, Position);
               Servo->IsBusy = TRUE;
               TIMER_SetTimer(Servo->Timer, SERVO_MOVEMENT_TIMEOUT, ServoMoveTimeoutHandler, (void *) Servo);
               return TRUE;
          }
     }
     return FALSE;
}

uint16 SERVO_AngleToPosition(ServoCtrl * Servo, float Angle)
{
     if(Servo)
     {
          if((Angle < 50.0f) && (Angle > -50.0f))
          {
               float abs = (Angle > 0) ? Angle : (-1.0f * Angle);
               uint16 sign = (Angle > 0) ? 1 : (-1);
               return (Servo->Center + (sign) * ((uint16)(abs * SERVO_STEPS_PER_45DEG / 45.0f)));
          }
     }
     return SERVO_DEFAULT_CENTER;
}

BOOL SERVO_IsBusy(ServoCtrl * Servo)
{
     if(Servo)
     {
          return Servo->IsBusy;
     }
     return FALSE;
}

static void ServoMoveTimeoutHandler(void * Servo)
{
     // Convert back the servo struct
     ServoCtrl * motor = (ServoCtrl *) Servo;
     if(motor)
     {
          motor->IsBusy = FALSE;
     }
}

void SERVO_SetCenter(ServoCtrl * Servo, uint16 Position)
{
     if(Servo)
     {
          Servo->Center = Position;
     }
}