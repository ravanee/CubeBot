#include "Types.h"
#include "UART.h"
#include "UART.h"

void UART_Init(void)
{
     UART_Init();
}
void UART_Task(void)
{
     UART_Task();
}
BOOL UART_Send(uint8 * Data, uint8 Length)
{
     return UART_Send(Data, Length);
}
BOOL UART_GetRx(uint8 * Data)
{
     return UART_GetRx(Data);
}

BOOL UART_IsActive(void)
{
     return UART_IsActive();
}